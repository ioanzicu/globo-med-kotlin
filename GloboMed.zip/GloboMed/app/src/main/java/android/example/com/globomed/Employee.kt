package android.example.com.globomed

class Employee (
    val id: String,
    val name: String,
    val dob: Long,
    val designation: String
)